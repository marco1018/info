import os
 

def classe(inputclasse):
    '''
        genera il file richiesta1.txt che contiene l'elenco dei docenti di una classe

            arguments:
                inputclasse (string): tre caratteri - classe di cui si vuole l'elenco dei docenti.es: 3GI
            
    '''
    nuovofile = open("richiesta1.txt", "w")
    file = open("OrarioTabellaGlobale.csv", "r")
    a = file.readline()
    while a != "":
        a = a.strip().split(",")
        for i in a:
            if i == inputclasse:
                print(a[0] + '\n')
                nuovofile.write(a[0] + '\n')
        a = file.readline()

   



    file.close()
    nuovofile.close()
    

