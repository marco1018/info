def classe(docente):
    """
    Crea un file di richiesta contenente il numero delle classi in cui il docente insegna.

    Arguments:
    docente (str): Il nome del docente di cui si desidera trovare il numero di classi in cui insegna.
                   Il nome deve corrispondere esattamente a come appare nel file "OrarioTabellaGlobale.txt".

    scrive il numero totale delle classi in cui insegna il docente in un nuovo file di richiesta chiamato "richiesta3".

    """
    c = 0
    with open("OrarioTabellaGlobale.txt", "r", encoding='utf-8') as file:
        for line in file:
            if docente in line:
                c += line.count("D")
    with open("richiesta3.txt", "w", encoding='utf-8') as nuovofile:
        nuovofile.write(str(c) + '\n')
    print(f"Numero di classi in cui insegna il docente {docente}: {c}")

docente = input("Inserisci il nome del docente: ")
classe(docente)