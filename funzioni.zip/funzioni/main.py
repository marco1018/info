import funzioni


def main():
    a = input("Quale funzione vuoi utilizzare? (1-4): ")

    
    a = int(a)

    if a == 1:
        funzioni.funzione1.classe(inputclasse=input("Inserisci il nome del docente: "))
    elif a == 2: 
        funzioni.funzione2.OrarioDocente(nome=input("Inserisci il Cognome Nome: ").upper())
    elif a == 3:
        funzioni.funzione3.classe(docente=input("Inserisci il nome del docente: "))
    elif a == 4:
        funzioni.funzione4.OraSpecifica(Giorno=input("Inserisci il nome del giorno: "), Ora=input("Inserisci il numero dell'ora: "))

main()