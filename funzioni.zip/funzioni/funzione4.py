def OraSpecifica(Giorno,Ora):
    """
    Estrae i nomi dei professori presenti in un giorno specifico e a un'ora specifica da un file CSV
    e scrive i risultati su un file di testo.

    Arguments:
        Giorno (str): Il giorno della settimana desiderato.
        Ora (int): L'ora del giorno desiderata.

    Output:
        Crea un file di testo 'OraSpecifica.txt' contenente i nomi dei professori presenti e il conteggio totale.

    """
    
    nomi = []
    spazio = [""]
    orario = []
    
    
    

    f = open('OrarioTabellaGlobale.csv','r')

    indice_ore = {"Lunedi":0, "Martedi":8, "Mercoledi":16, "Giovedi":24, "Venerdi":32}

    Ora = int(Ora)

    indice = indice_ore[Giorno] + Ora - 1
    docenti_ora_giorno = []
    contatore = 0

    for i in range(len(orario)):
        if orario[i][indice] != '   ':
            docenti_ora_giorno.append(nomi[i])
            contatore += 1
    f.close()
    file = open("OraSpecifica.txt",'w')
    for elmento in docenti_ora_giorno:
        file.write(elmento + "\n")
    file.write(f"Il numero di professori a lezione il {Giorno} alla {Ora} ora sono {contatore}")
    
    file.close()
    return
